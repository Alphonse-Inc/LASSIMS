<body>
<form action="bmpupload.php" method="post" enctype="multipart/form-data">
Image :<input type="file" name="file" id="file" multiple="multiple" />
<input type="submit" name="submit" value="submit" id="submit" />
</form>
</body>
<?php
if(isset($_POST['submit'])){
$image = $_FILES['file']['name'];
$ext = explode('.',$image);
$size = $_FILES['file']['size'];
$a=array("jpg","jpeg","JPG","JPEG","png","gif","GIF","bmp","BMP");
$submit = $_POST['submit'];
if((in_array($ext[1],$a)) && ($size<=5000000) && !empty($submit))
{
	echo "File is correct!";
	echo "<br/>";
	echo "Image :".$image;
	echo "<br/>";
	echo "Extention :".$ext[1]; 
	echo "<br/>";
	echo "Size :".$size;
	echo "<br/>";
	if(file_exists("biometrics/" .$image))
	{
		echo "file already exist!";
	}
	else
	{
	$upload=move_uploaded_file($_FILES["file"]["tmp_name"], "biometrics/" . $_FILES["file"]["name"]);
      echo "Stored in: " . "biometrics/" . $_FILES["file"]["name"];
	}
}
else 
{
	echo "Please check the extension and size of the file!";
	echo "<br/>";
}
}
?>