<?php

//loadPage.php

$requested_page = $_POST['selectedPage'];

switch($requested_page) {
  case "adoption":
    header("Location: searchentry.php");
  break;
  case "correctional":
    header("Location: searchentrycor.php");
  break;
  case "motherless":
    header("Location: searchentrymot.php");
  break;
  case "rehab":
    header("Location: searchentryreb.php");
  break;
  case "old":
    header("Location: searchentryold.php");
  break;
  case "social":
    header("Location: searchentry.php");
  break;
  case "research":
    header("Location: searchentry.php");
  break;
  case "youth":
    header("Location: searchentry.php");
  break;
  case "others":
    header("Location: searchentry.php");
  break;
  default :
    echo '<script>alert("Please Select a Department")</script>';
    header("Location: searchentry.php");
  break;
}
?>