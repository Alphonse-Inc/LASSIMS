<?php

$db = mysqli_connect('localhost', 'lsmysimscom', 'Lite@@@2019', 'lsmysimscom_lassims');
 
//set random name for the image, used time() for uniqueness

//Unique Alphanumeric Random Identifier
function random_codee($length)
{
  return substr(base_convert(sha1(uniqid(mt_rand())), 16, 36), 0, $length);
}

$uniqueID2 = random_codee(7);
 
$filename =  $uniqueID2 . '.jpg';
$filepath = '../saved_images/';
$imageudirloc = $filepath.$filename;

$sendimage = move_uploaded_file($_FILES['webcam']['tmp_name'], $imageudirloc);

?>