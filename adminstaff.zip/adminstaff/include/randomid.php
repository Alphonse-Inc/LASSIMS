<?php
function random_code($length)
{
  return substr(base_convert(sha1(uniqid(mt_rand())), 16, 36), 0, $length);
}

$uniqueID = random_code(7);

echo $uniqueID;
?>