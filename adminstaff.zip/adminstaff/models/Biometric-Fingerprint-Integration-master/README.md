# Biometric-Fingerprint-Integration
This module is made using Mantra SDK . I have integrated it in the project for biometric registration and authentication.
