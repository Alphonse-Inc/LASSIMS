<?php include('../include/server.php'); 

  // if user is not logged in, they cannot access this page
if (empty($_SESSION['username'])) {
  header('location: ../login.php');
}

if ($_SESSION['user_type'] !="Admin Staff"){
  header('location: ../login.php');
}

?>


<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <link rel="apple-touch-icon" sizes="76x76" href="assets/img/apple-icon.png">
  <link rel="icon" type="image/png" href="assets/img/favicon.png">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <title>
    LASSIMS
  </title>
  <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
  <!--     Fonts and icons     -->
  <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css">
  <!-- CSS Files -->
  <link href="assets/css/material-dashboard.css?v=2.1.0" rel="stylesheet" />
  <!-- CSS Just for demo purpose, don't include it in your project -->
  <link href="assets/demo/demo.css" rel="stylesheet" />
  <link rel="stylesheet" type=text/css href="style.css">
</head>

<body class="dark-edition">
  <div class="wrapper ">
    <div class="sidebar" data-color="green" data-background-color="black" data-image="assets/img/sidebar-2.jpg">
      <!--
        Tip 1: You can change the color of the sidebar using: data-color="purple | azure | green | orange | danger"

        Tip 2: you can also add an image using data-image tag
    -->
      <div class="logo">
        <a href="#" class="simple-text logo-normal">
          <img src="assets/img/logo.png">
        </a>
      </div>
      <div class="sidebar-wrapper">
        <ul class="nav">
          <li class="nav-item ">
            <a class="nav-link" href="dashboardm.php">
              <i class="material-icons">dashboard</i>
              <p>Dashboard</p>
            </a>
          </li>
          <li class="nav-item active">
            <a class="nav-link" href="usermanagerm.php">
              <i class="material-icons">supervisor_account</i>
              <p>User Management</p>
            </a>
          </li>
          <li class="nav-item ">
            <a class="nav-link" href="motherlessac.php">
              <i class="material-icons">supervisor_account</i>
              <p>Entry Notifications (<?php echo $count; ?>)</p>
            </a>
          </li>
          <li class="nav-item ">
            <a class="nav-link" href="searchentrymot.php">
              <i class="material-icons">search</i>
              <p>Search Entries</p>
            </a>
          </li>
          <li class="nav-item ">
            <a class="nav-link" href="../report-dashboard/index.php">
              <i class="material-icons">touch_app</i>
              <p>Goto Report Dashboard</p>
            </a>
          </li>
        </ul>
      </div>
    </div>
    <div class="main-panel">
      <!-- Navbar -->
      <nav class="navbar navbar-expand-lg navbar-transparent navbar-absolute fixed-top " id="navigation-example">
        <div class="container-fluid">
          <div class="navbar-wrapper">
            <a class="navbar-brand" href="javascript:void(0)">User Management</a>
          </div>
          <button class="navbar-toggler" type="button" data-toggle="collapse" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation" data-target="#navigation-example">
            <span class="sr-only">Toggle navigation</span>
            <span class="navbar-toggler-icon icon-bar"></span>
            <span class="navbar-toggler-icon icon-bar"></span>
            <span class="navbar-toggler-icon icon-bar"></span>
          </button>
          <div class="collapse navbar-collapse justify-content-end">
            <ul class="navbar-nav">              
              <li class="nav-item">
                <a class="nav-link" href="javascript:void(0)" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  <i class="material-icons">person</i>
                  <p class="d-lg-none d-md-block">
                    Account
                  </p>
                </a>
                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownMenuLink">
                  <?php if (isset($_SESSION["username"])): ?>
                    <a align="center"> Hello, <strong><?php echo $_SESSION['username']; ?></strong></a>
                    <a class="dropdown-item" href="change_pswm.php" style="color: black;">My Account</a>
                    <a class="dropdown-item" href="index.php?logout='1'" style="color: red;">Logout</a>
                  <?php endif ?>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </nav>
      <!-- End Navbar -->
      <div class="content">
        <div class="container-fluid">
          <div class="row">
            
      <div class="col-md-12">
              <div class="card card-plain">
                <div class="card-header card-header-primary">
                  <h4 class="card-title mt-0"> Available Users</h4>
                  <p class="card-category"> Below are the various users</p>
                </div>
              

<?php

// number of results to show per page
$per_page = 5;

//make connection
$db = mysqli_connect('localhost', 'lsmysimscom', 'Lite@@@2019', 'lsmysimscom_lassims');


$sql="SELECT * FROM users ORDER BY id";

if ($result = mysqli_query($db, $sql))
{
if ($result->num_rows != 0)
{
$total_results = $result->num_rows;
// ceil() returns the next highest integer value by rounding up value if necessary
$total_pages = ceil($total_results / $per_page);

// check if the 'page' variable is set in the URL (ex: view-paginated.php?page=1)
if (isset($_GET['page']) && is_numeric($_GET['page']))
{
$show_page = $_GET['page'];

// make sure the $show_page value is valid
if ($show_page > 0 && $show_page <= $total_pages)
{
$start = ($show_page -1) * $per_page;
$end = $start + $per_page;
}
else
{
// error - show first set of results
$start = 0;
$end = $per_page;
}
}
else
{
// if page isn't set, show first set of results
$start = 0;
$end = $per_page;
}
        // display data in table
echo "<table border='1' cellpadding='10'>";
echo "<tr> <th><font color=\"white\">USERNAME</font></th> <th><font color=\"white\">EMAIL</font></th> <th><font color=\"white\">USERTYPE</font></th> <th><font color=\"white\">USER CATEGORY</font></th> </tr>";

// loop through results of database query, displaying them in the table
for ($i = $start; $i < $end; $i++)
{
// make sure that PHP doesn't try to show results that don't exist
if ($i == $total_results) { break; }

// find specific row
$result->data_seek($i);
$row = $result->fetch_row();


echo "<tr><font color=\"white\">";
echo "<td><font color=\"white\">" . $row[1] . "</font></td>";
echo "<td><font color=\"white\">" . $row[2] . "</font></td>";
echo "<td><font color=\"white\">" . $row[3] . "</font></td>";
echo "<td><font color=\"white\">" . $row[4] . "</font></td>";
echo "</font></tr>";
}

// close table>
echo "</table>";      
// display pagination
echo "<p><font color=\"white\"><b>View Other Users:</b></font>  ";
for ($i = 1; $i <= $total_pages; $i++)
{
if (isset($_GET['page']) && $_GET['page'] == $i)
{
echo $i . " ";
}
else
{
echo "<a href='usermanagerm.php?page=$i'>$i</a> ";
}
}
echo "</p>";
}
}
//}

// confirm that the 'id' variable has been set
if (isset($_GET['id']) && is_numeric($_GET['id']))
{
// get the 'id' variable from the URL
$id = $_GET['id'];

// delete record from database
$sql_del = "DELETE FROM users WHERE id = $id";

if (mysqli_query($db, $sql_del)) {
    echo '<script>alert("SUCCESS! User deleted")</script>';
} else {
    echo '<script>alert("FAILED! User could not be deleted")</script>';
}

}

?>


                    </table>
                  </div>
                </div>
              </div>
            </div>


            <div class="container-fluid">
              <div class="row">  
                <div class="col-md-6">
                  <div class="card card-plain">
                    <div class="card-header card-header-primary">
                      <h4 class="card-title mt-0"> Create New Users</h4>
                      <p class="card-category"> You can create a new user below</p>
                    </div>
                    <div>
                      <form method="post" action="usermanagerm.php" enctype="multipart/form-data" id="usermanger">
                        <?php include('errors.php') ?>
                        <div class="card-body places-buttons">
                          <div class="row">
                            <div class="col-md-8">
                              <div class="form-group"><br>
                                <label class="bmd-label-floating"><h6>USERNAME:</h6></label>
                                <input type="text" class="form-control" name="username" value="<?php echo $username; ?>">
                              </div>
                            </div>
                          </div><br>
                          <div class="row">
                            <div class="col-md-8">
                              <div class="form-group"><br>
                                <label class="bmd-label-floating"><h6>EMAIL:</h6></label>
                                <input type="text" class="form-control" name="email" value="<?php echo $email; ?>">
                              </div>
                            </div>
                          </div><br>
                          <div class="row">
                            <div class="col-md-4">
                              <div class="form-group"><br>
                                <label class="bmd-label-floating"><h6>USER TYPE:</h6></label>
                                  <select class="dropdown-item" name="user_type" id="user_type" >
                                    <option value="">Select One</option>
                                    <option value="Admin">Admin</option>
                                    <option value="Admin Staff">Admin Staff</option>
                                    <option value="User">User</option>
                                  </select>
                              </div>
                            </div>
                          </div><br>
                          <div class="row">
                            <div class="col-md-4">
                              <div class="form-group"><br>
                                <label class="bmd-label-floating"><h6>USER CATEGORY:</h6></label>
                                  <select class="dropdown-item" name="user_cat" id="user_cat" >
                                    <option value="">Select One</option>
                                    <option value="Correctional Facilities">Correctional Facilities</option>
                                    <option value="Children Centres">Children Centres</option>
                                    <option value="Old Peoples Home">Old Peoples Home</option>
                                    <option value="Rehabilitation Centres">Rehabilitation Centres</option>
                                  </select>
                              </div>
                            </div>
                          </div><br>
                          <div class="row">
                            <div class="col-md-8">
                              <div class="form-group"><br>
                                <label class="bmd-label-floating"><h6>PASSWORD:</h6></label>
                                <input type="password" class="form-control" type="password" name="password_1">
                              </div>
                            </div>
                          </div><br>
                          <div class="row">
                            <div class="col-md-8">
                              <div class="form-group"><br>
                                <label class="bmd-label-floating"><h6>CONFIRM PASSWORD:</h6></label>
                                <input type="password" class="form-control" type="password" name="password_2">
                              </div>
                            </div>
                          </div><br>
                          <div class="clearfix"></div>
                        </div>
                        <button type="submit" value="submit" name="register" class="btn btn-primary pull-left">SUBMIT USER DETAILS</button>
                      </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <?php



        ?>
      <footer class="footer">
        <div class="container-fluid">
          <nav class="float-left">
            <ul>
              <li>
                <a href="#">
                  LASSIMS OFFICIAL
                </a>
              </li>
            </ul>
          </nav>
          <div class="copyright float-right" id="date">
          </div>
        </div>
      </footer>
      <script>
        const x = new Date().getFullYear();
        let date = document.getElementById('date');
        date.innerHTML = '&copy; ' + x + date.innerHTML;
      </script>
    </div>
  </div>
  <!--   Core JS Files   -->
  <script src="assets/js/core/jquery.min.js"></script>
  <script src="assets/js/core/popper.min.js"></script>
  <script src="assets/js/core/bootstrap-material-design.min.js"></script>
  <script src="https://unpkg.com/default-passive-events"></script>
  <script src="assets/js/plugins/perfect-scrollbar.jquery.min.js"></script>
  <!-- Place this tag in your head or just before your close body tag. -->
  <script async defer src="https://buttons.github.io/buttons.js"></script>
  <!--  Google Maps Plugin    -->
  <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>
  <!-- Chartist JS -->
  <script src="assets/js/plugins/chartist.min.js"></script>
  <!--  Notifications Plugin    -->
  <script src="assets/js/plugins/bootstrap-notify.js"></script>
  <!-- Control Center for Material Dashboard: parallax effects, scripts for the example pages etc -->
  <script src="assets/js/material-dashboard.js?v=2.1.0"></script>
  <!-- Material Dashboard DEMO methods, don't include it in your project! -->
  <script src="assets/demo/demo.js"></script>
  <script type="text/javascript">
    function ConfirmDelete()
      {
            if (confirm("Delete Account?"))
                 location.href='linktoaccountdeletion';
      }
    </script>
  <script>
    $(document).ready(function() {
      $().ready(function() {
        $sidebar = $('.sidebar');

        $sidebar_img_container = $sidebar.find('.sidebar-background');

        $full_page = $('.full-page');

        $sidebar_responsive = $('body > .navbar-collapse');

        window_width = $(window).width();

        $('.fixed-plugin a').click(function(event) {
          // Alex if we click on switch, stop propagation of the event, so the dropdown will not be hide, otherwise we set the  section active
          if ($(this).hasClass('switch-trigger')) {
            if (event.stopPropagation) {
              event.stopPropagation();
            } else if (window.event) {
              window.event.cancelBubble = true;
            }
          }
        });

        $('.fixed-plugin .active-color span').click(function() {
          $full_page_background = $('.full-page-background');

          $(this).siblings().removeClass('active');
          $(this).addClass('active');

          var new_color = $(this).data('color');

          if ($sidebar.length != 0) {
            $sidebar.attr('data-color', new_color);
          }

          if ($full_page.length != 0) {
            $full_page.attr('filter-color', new_color);
          }

          if ($sidebar_responsive.length != 0) {
            $sidebar_responsive.attr('data-color', new_color);
          }
        });

        $('.fixed-plugin .background-color .badge').click(function() {
          $(this).siblings().removeClass('active');
          $(this).addClass('active');

          var new_color = $(this).data('background-color');

          if ($sidebar.length != 0) {
            $sidebar.attr('data-background-color', new_color);
          }
        });

        $('.fixed-plugin .img-holder').click(function() {
          $full_page_background = $('.full-page-background');

          $(this).parent('li').siblings().removeClass('active');
          $(this).parent('li').addClass('active');


          var new_image = $(this).find("img").attr('src');

          if ($sidebar_img_container.length != 0 && $('.switch-sidebar-image input:checked').length != 0) {
            $sidebar_img_container.fadeOut('fast', function() {
              $sidebar_img_container.css('background-image', 'url("' + new_image + '")');
              $sidebar_img_container.fadeIn('fast');
            });
          }

          if ($full_page_background.length != 0 && $('.switch-sidebar-image input:checked').length != 0) {
            var new_image_full_page = $('.fixed-plugin li.active .img-holder').find('img').data('src');

            $full_page_background.fadeOut('fast', function() {
              $full_page_background.css('background-image', 'url("' + new_image_full_page + '")');
              $full_page_background.fadeIn('fast');
            });
          }

          if ($('.switch-sidebar-image input:checked').length == 0) {
            var new_image = $('.fixed-plugin li.active .img-holder').find("img").attr('src');
            var new_image_full_page = $('.fixed-plugin li.active .img-holder').find('img').data('src');

            $sidebar_img_container.css('background-image', 'url("' + new_image + '")');
            $full_page_background.css('background-image', 'url("' + new_image_full_page + '")');
          }

          if ($sidebar_responsive.length != 0) {
            $sidebar_responsive.css('background-image', 'url("' + new_image + '")');
          }
        });

        $('.switch-sidebar-image input').change(function() {
          $full_page_background = $('.full-page-background');

          $input = $(this);

          if ($input.is(':checked')) {
            if ($sidebar_img_container.length != 0) {
              $sidebar_img_container.fadeIn('fast');
              $sidebar.attr('data-image', '#');
            }

            if ($full_page_background.length != 0) {
              $full_page_background.fadeIn('fast');
              $full_page.attr('data-image', '#');
            }

            background_image = true;
          } else {
            if ($sidebar_img_container.length != 0) {
              $sidebar.removeAttr('data-image');
              $sidebar_img_container.fadeOut('fast');
            }

            if ($full_page_background.length != 0) {
              $full_page.removeAttr('data-image', '#');
              $full_page_background.fadeOut('fast');
            }

            background_image = false;
          }
        });

        $('.switch-sidebar-mini input').change(function() {
          $body = $('body');

          $input = $(this);

          if (md.misc.sidebar_mini_active == true) {
            $('body').removeClass('sidebar-mini');
            md.misc.sidebar_mini_active = false;

            $('.sidebar .sidebar-wrapper, .main-panel').perfectScrollbar();

          } else {

            $('.sidebar .sidebar-wrapper, .main-panel').perfectScrollbar('destroy');

            setTimeout(function() {
              $('body').addClass('sidebar-mini');

              md.misc.sidebar_mini_active = true;
            }, 300);
          }

          // we simulate the window Resize so the charts will get updated in realtime.
          var simulateWindowResize = setInterval(function() {
            window.dispatchEvent(new Event('resize'));
          }, 180);

          // we stop the simulation of Window Resize after the animations are completed
          setTimeout(function() {
            clearInterval(simulateWindowResize);
          }, 1000);

        });
      });
    });
  </script>
  <script>
    $(document).ready(function() {
      // Javascript method's body can be found in assets/js/demos.js
      md.initDashboardPageCharts();

    });
  </script>
</body>

</html>