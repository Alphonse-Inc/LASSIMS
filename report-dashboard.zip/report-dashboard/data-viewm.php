<?php include('../include/server.php'); 

$db = mysqli_connect('localhost', 'lsmysimscom', 'Lite@@@2019', 'lsmysimscom_lassims');


$id=$_REQUEST['id'];
$query = "SELECT * from motherless where id='".$id."'";
$result = mysqli_query($db, $query) or die ( mysqli_error());
$row = mysqli_fetch_assoc($result);

?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>LASSIMS | Report Dashboard</title>
    <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
    <!-- Bootstrap 3.3.2 -->
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <!-- Font Awesome Icons -->
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
    <!-- Ionicons -->
    <link href="http://code.ionicframework.com/ionicons/2.0.0/css/ionicons.min.css" rel="stylesheet" type="text/css" />

    <!-- Theme style -->
    <link href="dist/css/AdminLTE.min.css" rel="stylesheet" type="text/css" />
    <!-- AdminLTE Skins. Choose a skin from the css/skins 
         folder instead of downloading all of them to reduce the load. -->
    <link href="dist/css/skins/_all-skins.min.css" rel="stylesheet" type="text/css" />

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->
  </head>
  <body class="skin-blue">
    <div class="wrapper">
      
      <header class="main-header">
        <a href="../../index2.html" class="logo"><b>LASSIMS</b></a>
        <!-- Header Navbar: style can be found in header.less -->
        <nav class="navbar navbar-static-top" role="navigation">
          <!-- Sidebar toggle button-->
          <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
            <span class="sr-only">Toggle navigation</span>
          </a>
          <div class="navbar-custom-menu">
            <ul class="nav navbar-nav">
              <!-- Messages: style can be found in dropdown.less-->
              <li class="dropdown user user-menu">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                  <span class="hidden-xs">Admin</span>
                </a>
                <ul class="dropdown-menu">
                  <!-- User image -->
                  <li class="user-header">
                    <p>
                      Admin User
                      <small>LASSIM Staff</small>
                    </p>
                  </li>
                  
                  <!-- Menu Footer-->
                  <li class="user-footer">
                    <div class="pull-left">
                      <a href="#" class="btn btn-default btn-flat">Change Password</a>
                    </div>
                    <div class="pull-right">
                      <a href="../index.php" class="btn btn-default btn-flat">Sign out</a>
                    </div>
                  </li>
                </ul>
              </li>
            </ul>
          </div>
        </nav>
      </header>
      <!-- Left side column. contains the logo and sidebar -->
      <aside class="main-sidebar">
        <!-- sidebar: style can be found in sidebar.less -->
        <section class="sidebar">
          <!-- Sidebar user panel -->
          <div class="user-panel">
            <div class="pull-left info">
              <p>Admin</p>

              <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
            </div>
          </div>
          <!-- sidebar menu: : style can be found in sidebar.less -->
          <ul class="sidebar-menu">
            <li class="header">MAIN NAVIGATION</li>
            <li class="treeview">
              <a href="index.php">
                <i class="fa fa-dashboard"></i> <span>Dashboard</span>
              </a>
            </li>
            <li class="treeview">
              <a href="#">
                <i class="fa fa-pie-chart"></i>
                <span>Report By Education</span>
                <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li><a href="redu.php"><i class="fa fa-circle-o"></i> Formal vs Informal/Vocation</a></li>
              </ul>
            </li>
            <li class="treeview">
              <a href="rhealth.php">
                <i class="fa fa-pie-chart"></i>
                <span>Report By Health</span>
              </a>
            </li>
            <li class="treeview">
              <a href="rstate.php">
                <i class="fa fa-pie-chart"></i>
                <span>Report By State</span>
                <i class="fa fa-angle-left pull-right"></i>
              </a>
            </li>
            <li class="treeview">
              <a href="#">
                <i class="fa fa-pie-chart"></i>
                <span>Number of Service Users</span>
                <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li><a href="rage.php"><i class="fa fa-circle-o"></i> By Age Range</a></li>
              </ul>
            </li>
            <li class="treeview">
              <a href="capvsuser.php">
                <i class="fa fa-pie-chart"></i>
                <span>Facility Capacity Vs Users</span>
              </a>
            </li>
            <li class="active treeview">
              <a href="#">
                <i class="fa fa-pie-chart"></i>
                <span>View All Entries</span>
                <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li><a href="datac.php"><i class="fa fa-circle-o"></i> Correctional Centres</a></li>
              </ul>
              <ul class="treeview-menu">
                <li><a href="datam.php"><i class="fa fa-circle-o"></i> Motherless/Child Centres</a></li>
              </ul>
              <ul class="treeview-menu">
                <li><a href="datao.php"><i class="fa fa-circle-o"></i> Old People's Home</a></li>
              </ul>
              <ul class="treeview-menu">
                <li><a href="datar.php"><i class="fa fa-circle-o"></i> Rehabilitation Centres</a></li>
              </ul>
            </li>
          </ul>
        </section>
        <!-- /.sidebar -->
      </aside>

      <!-- Right side column. Contains the navbar and content of the page -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            LASSIMS GENERAL REPORT DASHBOARD
            <small>Control panel</small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="index.php"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">All Entries</li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
          <div class="row">
            <div class="col-md-8">
              <div class="">
                <div class="box-header">
                  <img src="dist/img/LOGOedited.jpg" alt=""/><h3 class="box-title">LASSIMS Report</h3><div id="results" style="height:100px;width:100px" class="pull-right">
                    <img src="<?php echo $row['image'];?>" alt="" style="width:100%; height:100%"/>
                  </div>
                </div><!-- /.box-header -->
                <div class="box-body">
                
              <div class="box">
                <div class="box-header">
                  <h3 class="box-title">Personal Information</h3>
                </div><!-- /.box-header -->
                <div class="box-body no-padding">
                  <table class="table table-condensed">
                    <tr>
                      <th>Name: </th>
                      <th>Gender: </th>
                      <th>Date of Birth/Age: </th>
                    </tr>
                    <tr>
                      <td><?php echo $row['name'];?></td>
                      <td><?php echo $row['gender'];?></td>
                      <td><?php echo $row['dob'];?></td>
                    </tr>

                  </table>
                </div><!-- /.box-body -->
              </div><!-- /.box -->

              <div class="box">
                <div class="box-header">
                  <h3 class="box-title">Physical Information</h3>
                </div><!-- /.box-header -->
                <div class="box-body no-padding">
                  <table class="table table-condensed">
                    <tr>
                      <th>Weight(kg): </th>
                      <th>Height(cm): </th>
                      <th>Tribal Marks: </th>
                    </tr>
                    <tr>
                      <td><?php echo $row['weight'];?></td>
                      <td><?php echo $row['height'];?></td>
                      <td><?php echo $row['tribalmarks'];?></td>
                    </tr>
                    <tr>
                      <th>Complexion: </th>
                      <th>Hair Colour: </th>
                    </tr>
                    <tr>
                      <td><?php echo $row['complexion'];?></td>
                      <td><?php echo $row['haircolour'];?></td>
                    </tr>

                  </table>
                </div><!-- /.box-body -->
              </div><!-- /.box -->

              <div class="box">
                <div class="box-header">
                  <h3 class="box-title">Educational Information</h3>
                </div><!-- /.box-header -->
                <div class="box-body no-padding">
                  <table class="table table-condensed">
                    <tr>
                      <th>Education Type: </th>
                      <th>Educational Level: </th>
                    </tr>
                    <tr>
                      <td><?php echo $row['educationtype'];?></td>
                      <td><?php echo $row['educationlevel'];?></td>
                    </tr>

                  </table>
                </div><!-- /.box-body -->
              </div><!-- /.box -->

              <div class="box">
                <div class="box-header">
                  <h3 class="box-title">Health Information</h3>
                </div><!-- /.box-header -->
                <div class="box-body no-padding">
                  <table class="table table-condensed">
                    <tr>
                      <th>Any Illness: </th>
                      <th>Type of Illness: </th>
                    </tr>
                    <tr>
                      <td><?php echo $row['illness'];?></td>
                      <td><?php echo $row['illnesstype'];?></td>
                    </tr>

                  </table>
                </div><!-- /.box-body -->
              </div><!-- /.box -->

              <div class="box">
                <div class="box-header">
                  <h3 class="box-title">Other Information</h3>
                </div><!-- /.box-header -->
                <div class="box-body no-padding">
                  <table class="table table-condensed">
                    <tr>
                      <th>Location of Pickup: </th>
                      <th>Reason for Being at home: </th>
                      <th>Status: </th>
                    </tr>
                    <tr>
                      <td><?php echo $row['location'];?></td>
                      <td><?php echo $row['otherreasons'];?></td>
                      <td>Released<?php echo $row['status'];?></td>
                    </tr>
                  </table>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div>
        <button onClick="this.style.visibility= 'hidden'; [window.print()]" class="pull-right hide-from-printer">Print this report</button>
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->


      <footer class="main-footer">
        <div class="pull-right">
          <img src="stamp.png">
        </div>
        <strong>Copyright &copy; 2019 <a href="#">LASSIMS</a>.</strong> All rights reserved.
      </footer>
    </div><!-- ./wrapper -->

    <!-- jQuery 2.1.3 -->
    <script src="plugins/jQuery/jQuery-2.1.3.min.js"></script>
    <!-- Bootstrap 3.3.2 JS -->
    <script src="bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
    <!-- Slimscroll -->
    <script src="plugins/slimScroll/jquery.slimscroll.min.js" type="text/javascript"></script>
    <!-- FastClick -->
    <script src='plugins/fastclick/fastclick.min.js'></script>
    <!-- AdminLTE App -->
    <script src="dist/js/app.min.js" type="text/javascript"></script>
    <!-- AdminLTE for demo purposes -->
    <script src="dist/js/demo.js" type="text/javascript"></script>

<script type="text/javascript">
    //JAVASCRIPT FOR THE WEBCAM
    Webcam.set({
        width: 490,
        height: 390,
        image_format: 'jpeg',
        jpeg_quality: 90
    });
  
    function setup() {
            Webcam.reset();
            Webcam.attach( '#my_camera' );
        }
  
    function take_snapshot() {
        Webcam.snap( function(data_uri) {

            Webcam.upload( data_uri, 'saveimage.php', function(code, text) {
          document.getElementById('results').innerHTML =  
          '<img src="'+text+'"/>';

        } );
    } );
  }
</script>

<script type="text/javascript">
function block_none(){
 document.getElementById('hidden-div').classList.add('show');
document.getElementById('button-id').classList.add('hide');
}
</script>

  </body>
</html>
