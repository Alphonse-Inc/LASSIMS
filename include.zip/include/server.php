<?php
	session_start();
	$username = "";
	$email = "";
	$errors = array();

	error_reporting(0);

	define("UPLOAD_DIR", "files/", true) ;

	// connect to the database
	$db = mysqli_connect('localhost', 'lsmysimscom', 'Lite@@@2019', 'lsmysimscom_lassims');

	// if the register location is clicked
	if (isset($_POST['register'])) {
		$username = mysqli_real_escape_string($db, $_POST['username']);
		$email = mysqli_real_escape_string($db, $_POST['email']);
		$user_type = mysqli_real_escape_string($db, $_POST['user_type']);
		$user_cat = mysqli_real_escape_string($db, $_POST['user_cat']);
		$password_1 = mysqli_real_escape_string($db, $_POST['password_1']);
		$password_2 = mysqli_real_escape_string($db, $_POST['password_2']);

		// ensure that form feilds are filled properly
		if (empty($username)) {
			array_push($errors, "Username is required");
		}
		if (empty($email)) {
			array_push($errors, "Email is required");
		}
		if (empty($user_type)) {
			array_push($errors, "Please select a usertype");
		}
		if (empty($user_cat)) {
			array_push($errors, "<script>alert('Please, select a user category)</script>");
		}
		if (empty($password_1)) {
			array_push($errors, "Pasword is required");
		}

		if ($password_1 != $password_2) {
			array_push($errors, "The two passwords do not match");
		}

		// if there are no errors, save user to database
		if (count($errors) == 0) {
			$password = md5($password_1); //encrypt password before storing in database (security)
			if (isset($_POST['user_type'])) {
				$query = "INSERT INTO users (username, email, user_type, user_cat, password) 
						 VALUES('$username', '$email', '$user_type', '$user_cat', '$password')";
				mysqli_query($db, $query);
				echo '<script>alert("Congratulations. A new user has been successfully created!!")</script>';
				$_SESSION['success']  = "New user successfully created!!";
			}
			else{
				$query = "INSERT INTO users (username, email, user_type, user_cat, password) 
						  VALUES('$username', '$email', '$user_type', '$user_cat', '$password')";
				mysqli_query($db, $query);

				// get id of the created user
				$logged_in_user_id = mysqli_insert_id($db);

				$_SESSION['user'] = getUserById($logged_in_user_id); // put logged in user in session
				$_SESSION['success']  = "You are now logged in";
				header('location: dashboard.php');				
			}
		}
	}

// return user array from their id
function getUserById($id){
	global $db;
	$query2 = "SELECT * FROM users WHERE id=" . $id;
	$result = mysqli_query($db, $query2);

	$user = mysqli_fetch_assoc($result);
	return $user;
}

	// log user in from login page
	if (isset($_POST['login'])) {
		$username = mysqli_real_escape_string($db, $_POST['username']);
		$password = mysqli_real_escape_string($db, $_POST['password']);
		$user_type1 = "Admin";
		$user_type2 = "User";
		$user_type3 = "Admin Staff";
		$user_cat1 = "Correctional Facilities";
		$user_cat2 = "Rehabilitation Centres";
		$user_cat3 = "Children Centres";
		$user_cat4 = "Old Peoples Home";

		// ensure that form feilds are filled properly
		if (empty($username)) {
			array_push($errors, "Username is required");
		}
		if (empty($password)) {
			array_push($errors, "Password is required");
		}

		if (count($errors) == 0 ) {
			$password = md5($password); // encrypt password before comparing with that from database
			$query1 = "SELECT * FROM users WHERE username='$username' AND password='$password' AND user_type='$user_type1'";
			$query2 = "SELECT * FROM users WHERE username='$username' AND password='$password' AND user_type='$user_type2'";
			$query3 = "SELECT * FROM users WHERE username='$username' AND password='$password' AND user_type='$user_type3' AND user_cat='$user_cat1'";
			$query4 = "SELECT * FROM users WHERE username='$username' AND password='$password' AND user_type='$user_type3' AND user_cat='$user_cat2'";
			$query5 = "SELECT * FROM users WHERE username='$username' AND password='$password' AND user_type='$user_type3' AND user_cat='$user_cat3'";
			$query6 = "SELECT * FROM users WHERE username='$username' AND password='$password' AND user_type='$user_type3' AND user_cat='$user_cat4'";
			$result1 = mysqli_query($db, $query1);
			$result2 = mysqli_query($db, $query2);
			$result3 = mysqli_query($db, $query3);
			$result4 = mysqli_query($db, $query4);
			$result5 = mysqli_query($db, $query5);
			$result6 = mysqli_query($db, $query6);

			if (mysqli_num_rows($result1) == 1) {
				// log user in
				$_SESSION['username'] = $username;
				$_SESSION['user_type'] = $user_type1;
				$_SESSION['success'] = "You are now logged in";
				header('location: admin/dashboard.php'); // redirect to homepage
			}
			if (mysqli_num_rows($result2) == 1) {
				// log user in
				$_SESSION['username'] = $username;
				$_SESSION['user_type2'] = $user_type2;
				$_SESSION['success'] = "You are now logged in";
				header('location: dataentry/dashboard.php'); // redirect to homepage
			}
			if (mysqli_num_rows($result3) == 1) {
				// log user in
				$_SESSION['username'] = $username;
				$_SESSION['user_type'] = $user_type3;
				$_SESSION['user_cat'] = $user_cat1;
				$_SESSION['success'] = "You are now logged in";
				header('location: adminstaff/dashboardc.php'); // redirect to homepage
			}
			if (mysqli_num_rows($result4) == 1) {
				// log user in
				$_SESSION['username'] = $username;
				$_SESSION['user_type'] = $user_type3;
				$_SESSION['user_cat'] = $user_cat2;
				$_SESSION['success'] = "You are now logged in";
				header('location: adminstaff/dashboardr.php'); // redirect to homepage
			}
			if (mysqli_num_rows($result5) == 1) {
				// log user in
				$_SESSION['username'] = $username;
				$_SESSION['user_type'] = $user_type3;
				$_SESSION['user_cat'] = $user_cat3;
				$_SESSION['success'] = "You are now logged in";
				header('location: adminstaff/dashboardm.php'); // redirect to homepage
			}
			if (mysqli_num_rows($result6) == 1) {
				// log user in
				$_SESSION['username'] = $username;
				$_SESSION['user_type'] = $user_type3;
				$_SESSION['user_cat'] = $user_cat4;
				$_SESSION['success'] = "You are now logged in";
				header('location: adminstaff/dashboardo.php'); // redirect to homepage
			}else{
				array_push($errors, "Wrong Username/Password Combination");
			}
		}
	}

	// logout
	if (isset($_GET['logout'])) {
		session_destroy();
		unset($_SESSION['username']);
		header('location: ../login.php');
	}

?>