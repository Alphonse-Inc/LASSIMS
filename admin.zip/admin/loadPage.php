<?php

//loadPage.php

$requested_page = $_POST['selectedPage'];

switch($requested_page) {
  case "adoption":
    header("Location: adoptionform.php");
  break;
  case "correctional":
    header("Location: correctional.php");
  break;
  case "motherless":
    header("Location: motherless.php");
  break;
  case "rehab":
    header("Location: rehab.php");
  break;
  case "old":
    header("Location: old.php");
  break;
  case "social":
    header("Location: addentry.php");
  break;
  case "research":
    header("Location: addentry.php");
  break;
  case "youth":
    header("Location: addentry.php");
  break;
  case "others":
    header("Location: addentry.php");
  break;
  default :
    echo '<script>alert("Please Select a Department")</script>';
    header("Location: addentry.php");
  break;
}
?>