<?php
$files = scandir('saved_images', SCANDIR_SORT_DESCENDING);
$newest = $files[0];
$newest_file = 'saved_images/' . $newest;
echo $newest_file;
?>